#! /usr/bin/env python
# _*_ coding: UTF-8 _*_ 
# Filename: ProtocolCtrl.py

import os
from Tkinter import *
import ttk
import webbrowser

dependencyDict = {
	'netifaces27'	:	'./dependency/' + 'netifaces-0.10.6-cp27-cp27mu-linux_x86_64.whl',
	}

try:
    import netifaces
except ImportError:
    try:		
        command_to_execute = "echo 'NOTICE:Need to install dependencies\n';sudo pip install " + dependencyDict['netifaces27']
        os.system(command_to_execute)
    except OSError:
        print "Can NOT install netifaces, Aborted!"
        sys.exit(1)
    import netifaces

# onvif cmd para define
onvifDict = {
	'onvifBin' : 'mantisONVIFServer',
	'rtspIpAddr' : '',
	'rtspPort' : '17100',
	'onvifPort' : '21100',
	'onvifLogoFile' : './logo/onvifLogo.png'
	}

# 28181 cmd/cfg para define
gbCfgList = ('server_id', 'server_ip', 'server_port', 'device_id', 'listen_port', 'username', 'password', 'alarm_id', 'media_id', 'register_expire')
gbDict =  {
	'gbCfgFileName' : '/etc/aqueti/GB/mantisGBprofile.conf',
	'gbCfgFileDir' : '/etc/aqueti/GB/',
	'gbBin' : 'mantisGBclient',
	'gbLogoFile' : './logo/gb28181Logo.png'
	}

gbCfgFilePrefix = '{\n  "keepalive_timeout":10,\n  "re-register_timeout":60,\n  "keepalive_timeout_num":3,\n  "user_profile":{\n'
gbCfgFileSuffix ='  }\n}'

helpDocDict = {
	'onvifHelp' : './help/Mantis_ONVIF_help' + '.docx',
	'gb28181Help' : './help/Mantis_ONVIF_help' + '.docx',
	}

root = Tk()
#root.geometry('450x400')
root.resizable(True, False)
root.attributes("-alpha",0.6)
#1 title
root.title('ProtocolCtrl')

#2 meun
def quit_window():
	root.quit()
	root.destroy()
	exit()
	
def click_help_onvif():
	top = Toplevel()
	top.title('ONVIF user manual')
	Label(top, text='\nPlease check the protocol user manual.\nContact information of software team:li.min@aqueti.com.\n').pack()
	webbrowser.open(helpDocDict['onvifHelp'])

def click_help_gb28181():
	top = Toplevel()
	top.title('GB28181 user manual')
	Label(top, text='\nPlease check the protocol user manual.\nContact information of software team:li.min@aqueti.com.\n').pack()
	webbrowser.open(helpDocDict['gb28181Help'])
	
def click_start_onvif(sudo, rip, rp, op):
	print "click_start_onvif", sudo, rip, rp, op

	if sudo:
		start_onvif_commad = 'sudo ' + onvifDict['onvifBin']
	else:
		start_onvif_commad = onvifDict['onvifBin']
		
	if '' == rip.strip():
		start_onvif_commad += ' -rip ' + onvifDict['rtspIpAddr']
	else:
		start_onvif_commad += ' -rip ' + rip
	
	if '' == rp.strip():
		start_onvif_commad += ' -rp ' + onvifDict['rtspPort']
	else:
		start_onvif_commad += ' -rp ' + rp
		
	if '' != op.strip():
		start_onvif_commad += ' -op ' + op
	print ('Start onvifServer CMD [' + start_onvif_commad + "]")
	# start onvifServer
	if os.system(start_onvif_commad) == 0:
		print 'Successful START onvifServer on', start_onvif_commad
	else:
		print 'START onvifServer Completed'
	
def reInstall_onvif():
	rebuild_commad = 'sudo dpkg -r mantis_onvifserver;'
	rebuild_commad += 'make ONVIFServer;'
	rebuild_commad += 'sudo dpkg -i INSTALL/deb/mantis_ONVIFServer-0.1.0.5_.deb'
	
	# start onvifServer
	if os.system(rebuild_commad) == 0:
		print 'Successful ReInstall onvifServer on', rebuild_commad
	else:
		print 'ReInstall onvifServer Completed'

def click_start_gb():
	# start gbClient
	if os.system(gbDict['gbBin']) == 0:
		print 'Successful START gb28181 client on', gbBin
	else:
		print 'START gb28181 client Completed'

def update_gb_content_dict():
	gb_content_dict = {}
	gb_content_dict['server_id'] = gbSid.get()
	gb_content_dict['server_ip'] = gbSip.get()
	gb_content_dict['server_port'] = gbSpo.get()
	gb_content_dict['device_id'] = gbDid.get()
	gb_content_dict['listen_port'] = gbLpo.get()
	gb_content_dict['username'] = gbUsername.get()
	gb_content_dict['password'] = defgbPwd.get()
	gb_content_dict['alarm_id'] = gbAid.get()
	gb_content_dict['media_id'] = gbMid.get()
	gb_content_dict['register_expire'] = gbRex.get()
	return gb_content_dict	

def find_old_key_val(cfgLine, var):
	reStr = '"' + var + '":"(.*)",'
	pattern = re.compile(reStr)
	vallist = pattern.findall(cfgLine)
	if vallist:
		return vallist[0]
	else:
		reStr = '"' + var + '":(.*),'
		pattern = re.compile(reStr)
		vallist = pattern.findall(cfgLine)
		if vallist:
			return vallist[0]
		else:
			reStr = '"' + var + '":(.*)'
			pattern = re.compile(reStr)
			vallist = pattern.findall(cfgLine)
			if vallist:
				return vallist[0]
			else:
				return ''
				
def get_str_value_from_file(filepath, oldStr):
	with open(filepath, "r") as f:
		for line in f:
			if oldStr in line:
				return find_old_key_val(line, oldStr)
		return ''

def replace_oldstr_value_from_file(filepath, oldStr, newStrValue):
	with open(filepath, "r") as f:
		for line in f:
			if oldStr in line:
				oldStrvalue = find_old_key_val(line, oldStr)
				if oldStrvalue:
					line = line.replace(oldStrvalue, newStrValue)
				return line

def update_gbcfg_file(filepath, file_content):
	with open(filepath, "w") as f:
		f.write(file_content)
				
def update_gb_cfg():
	gbcontent_dict = update_gb_content_dict()
	file_new_data = ''
	for index in range(len(gbCfgList)):
		file_new_data += replace_oldstr_value_from_file(gbDict['gbCfgFileName'], gbCfgList[index], gbcontent_dict[gbCfgList[index]])
	print  file_new_data
	file_content =  gbCfgFilePrefix + file_new_data +  gbCfgFileSuffix
	print file_content
	update_gbcfg_file(gbDict['gbCfgFileName'], file_content)

def check_and_create_file(dirpath, filepath):
	try:
		if not(os.path.exists(dirpath)) and not(os.path.isfile(filepath)):
			os.mkdir(dirpath)
		if not(os.path.exists(filepath) and os.path.isfile(filepath)):
			with open(filepath, 'w') as f:
				file_content =  gbCfgFilePrefix + gbCfgFileSuffix
				f.write(file_content)
	except OSError:
		print ("To detect the uninstalled mantis or GB28181, configure the environment first.")
    	return	

def get_ip_list():
	netCardList = netifaces.interfaces()
	ipv4List = []
	for netCardName in netCardList:
		ipv4 = get_ip_address(netCardName)
		if ipv4.strip():
			ipv4List.append(ipv4)
	return ipv4List

def get_ip_address(ifname):
	ipStr = ''
	try:
		ipStr = netifaces.ifaddresses(ifname)[2][0]['addr']
	except:
		print ("Err:Please check whether the network card [" + ifname + "] is properly configured with address information.")
	return ipStr

xmenu = Menu(root)
submenu = Menu(xmenu, tearoff = 0)

submenu.add_command(label = 'ONVIF user manual', command = click_help_onvif)
submenu.add_command(label = 'GB28181 user manual', command = click_help_gb28181)

xmenu.add_cascade(label = 'Help', menu = submenu)
xmenu.add_command(label = 'Exit', command = quit_window)

#3 content
# para
ParaFrame = LabelFrame(root, text='ONVIF Ctrl', height = 2, fg = 'green')
ParaFrame.grid(row=0, column=0, padx=10, pady=10)

# onvif start para
OnvifFrame = LabelFrame(ParaFrame, text=' Parameter ')
OnvifFrame.grid(row=0, column=0, padx=10, pady=10) 

onvifParaIndex = 1
for item in ['Admin  ', 'Rtsp Ip  ', 'Rtsp Port  ', 'Onvif Port  ']:
	Label(OnvifFrame, text=item, width = 13, height = 2, anchor='e').grid(row=onvifParaIndex,column=0)
	onvifParaIndex += 1

CB = IntVar(); Checkbutton(OnvifFrame, text="Enabled",variable = CB).grid(row=1,column=1)
defRIP = StringVar(); ipv4List = ttk.Combobox(OnvifFrame, textvariable=defRIP, width=21); 
ipv4List["values"]= get_ip_list(); ipv4List.current(1); ipv4List.grid(row=2,column=1)
defRP = StringVar(); defRP.set(onvifDict['rtspPort']); RP = Entry(OnvifFrame, textvariable = defRP, width=23); RP.grid(row=3,column=1)
defOP = StringVar(); defOP.set(onvifDict['onvifPort']); OP = Entry(OnvifFrame, textvariable = defOP, width=23); OP.grid(row=4,column=1)

# button ctrl onvif
StartFrame = LabelFrame(ParaFrame, text=' Command ')
StartFrame.grid(row=0, column=1, padx=10, pady=10, sticky=N)
onvifLogo = PhotoImage(file=onvifDict['onvifLogoFile'])
Label(StartFrame, image=onvifLogo).grid(row=0, column=0, columnspan=2)
Button(StartFrame, text = 'Start ONVIF', width = 12, height = 2, borderwidth=2, bg = 'green', \
		command=lambda:click_start_onvif(CB.get(), ipv4List.get(), RP.get(), OP.get())).grid(row=1,column=0, padx=10, pady=10)
Button(StartFrame, text = 'ReInstall ONVIF', width = 12, height = 2, bg = 'green', \
		command=lambda:reInstall_onvif()).grid(row=1,column=1, padx=10, pady=10)

#28181 Ctrl
Gb28181Frame = LabelFrame(root, text=' GB28181 Ctrl ', fg = 'green')
Gb28181Frame.grid(row=1, column=0, padx=10, pady=10)

GbFrame = LabelFrame(Gb28181Frame, text=' user_profile ')
GbFrame.grid(row=0, column=0, padx=10, pady=10)

# check and  create gb cfg file
check_and_create_file(gbDict['gbCfgFileDir'], gbDict['gbCfgFileName'])
# gb para
for index in range(len(gbCfgList)):
	 Label(GbFrame, text=gbCfgList[index] + '  ',width = 13, height = 2, anchor='e').grid(row=index,column=0)
defgbSid = StringVar(); defgbSid.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'server_id')); gbSid = Entry(GbFrame, textvariable = defgbSid, width=23); gbSid.grid(row=0, column=1, padx=10)
defgbSip = StringVar(); defgbSip.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'server_ip')); gbSip = Entry(GbFrame, textvariable = defgbSip, width=23); gbSip.grid(row=1,column=1)
defgbSpo = StringVar(); defgbSpo.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'server_port')); gbSpo = Entry(GbFrame, textvariable = defgbSpo, width=23); gbSpo.grid(row=2,column=1)
defgbDid = StringVar(); defgbDid.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'device_id')); gbDid = Entry(GbFrame, textvariable = defgbDid, width=23); gbDid.grid(row=3,column=1)
defgbLpo = StringVar(); defgbLpo.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'listen_port')); gbLpo = Entry(GbFrame, textvariable = defgbLpo, width=23); gbLpo.grid(row=4,column=1)
defgbUsername = StringVar(); defgbUsername.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'username')); gbUsername = Entry(GbFrame, textvariable = defgbUsername, width=23); gbUsername.grid(row=5,column=1)
defgbPwd = StringVar(); defgbPwd.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'password')); gbPwd = Entry(GbFrame, textvariable = defgbPwd, width=23, show='*'); gbPwd.grid(row=6,column=1)
defgbAid = StringVar(); defgbAid.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'alarm_id')); gbAid = Entry(GbFrame, textvariable = defgbAid, width=23); gbAid.grid(row=7,column=1)
defgbMid = StringVar(); defgbMid.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'media_id')); gbMid = Entry(GbFrame, textvariable = defgbMid, width=23); gbMid.grid(row=8,column=1)
defgbRex = StringVar(); defgbRex.set(get_str_value_from_file(gbDict['gbCfgFileName'], 'register_expire')); gbRex = Entry(GbFrame, textvariable = defgbRex, width=23); gbRex.grid(row=9,column=1)

# button ctrl 28181
Ctrl28181Frame = LabelFrame(Gb28181Frame, text=' Command ')
Ctrl28181Frame.grid(row=0, column=1, padx=10, pady=10, sticky=N)
gbLogo = PhotoImage(file=gbDict['gbLogoFile'])
Label(Ctrl28181Frame, image=gbLogo).grid(row=0, column=0, columnspan=2)
Button(Ctrl28181Frame, text = 'Update 28181 Cfg', width = 12, height = 2, bg = 'green', \
		command=lambda:update_gb_cfg()).grid(row=1,column=0, padx=10, pady=10)
Button(Ctrl28181Frame, text = 'Start 28181', width = 12, height = 2, bg = 'green', \
		command=lambda:click_start_gb()).grid(row=1,column=1, padx=10, pady=10)

root['menu'] = xmenu

root.mainloop()
